Add all libraries from the game(Stationeers\rocketstation_Data\Managed) except:
starting with Unity.
starting with UnityEngine.

Add the following libraries from the BepInEx(Stationeers\BepInEx\core):
0Harmony.dll
MonoMod.RuntimeDetour.dll
MonoMod.Utils.dll

You can add any other libraries when you need them to compile the project